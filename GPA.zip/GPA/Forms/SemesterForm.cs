﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace GPA_Calculator.Forms
{
    public partial class SemesterForm : Form
    {
        private Panel pnlInputCard;
        private TextBox txtCourseCode;
        private TextBox txtCourseName;
        private TextBox txtCredits;
        private ComboBox cmbGrade;
        private Button btnAdd;

        private DataGridView dgvSubjects;
        private Button btnCalculate;
        private Button btnSave;

        public string SemesterName { get; set; } = "Semester 1";

        public SemesterForm()
        {
            InitializeComponent();
            SetupModernUI();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            LoadCoursesFromDatabase();
        }

        private void SetupModernUI()
        {
            this.Text = "Manage Semester Courses - " + SemesterName;
            this.Size = new Size(880, 620);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.FromArgb(245, 247, 250);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            pnlInputCard = new Panel();
            pnlInputCard.Size = new Size(820, 110);
            pnlInputCard.Location = new Point(25, 20);
            pnlInputCard.BackColor = Color.White;
            pnlInputCard.Paint += (s, e) => {
                ControlPaint.DrawBorder(e.Graphics, pnlInputCard.ClientRectangle,
                    Color.FromArgb(220, 224, 230), ButtonBorderStyle.Solid);
            };

            Label lblCode = new Label() { Text = "Course Code", Font = new Font("Segoe UI", 9, FontStyle.Bold), Location = new Point(15, 12), AutoSize = true, ForeColor = Color.FromArgb(100, 116, 139) };
            txtCourseCode = new TextBox() { Location = new Point(15, 35), Size = new Size(110, 27), Font = new Font("Segoe UI", 10) };

            Label lblName = new Label() { Text = "Course Name", Font = new Font("Segoe UI", 9, FontStyle.Bold), Location = new Point(140, 12), AutoSize = true, ForeColor = Color.FromArgb(100, 116, 139) };
            txtCourseName = new TextBox() { Location = new Point(140, 35), Size = new Size(260, 27), Font = new Font("Segoe UI", 10) };

            Label lblCredits = new Label() { Text = "Credits", Font = new Font("Segoe UI", 9, FontStyle.Bold), Location = new Point(415, 12), AutoSize = true, ForeColor = Color.FromArgb(100, 116, 139) };
            txtCredits = new TextBox() { Location = new Point(415, 35), Size = new Size(75, 27), Font = new Font("Segoe UI", 10) };

            Label lblGrade = new Label() { Text = "Grade", Font = new Font("Segoe UI", 9, FontStyle.Bold), Location = new Point(505, 12), AutoSize = true, ForeColor = Color.FromArgb(100, 116, 139) };
            cmbGrade = new ComboBox() { Location = new Point(505, 35), Size = new Size(90, 27), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbGrade.Items.AddRange(new object[] { "A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "E" });
            cmbGrade.SelectedIndex = 0;

            btnAdd = new Button();
            btnAdd.Text = "+ Add Subject";
            btnAdd.Location = new Point(615, 33);
            btnAdd.Size = new Size(185, 32);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.BackColor = Color.FromArgb(37, 99, 235);
            btnAdd.ForeColor = Color.White;
            btnAdd.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnAdd.Cursor = Cursors.Hand;
            btnAdd.Click += BtnAdd_Click;

            pnlInputCard.Controls.Add(lblCode);
            pnlInputCard.Controls.Add(txtCourseCode);
            pnlInputCard.Controls.Add(lblName);
            pnlInputCard.Controls.Add(txtCourseName);
            pnlInputCard.Controls.Add(lblCredits);
            pnlInputCard.Controls.Add(txtCredits);
            pnlInputCard.Controls.Add(lblGrade);
            pnlInputCard.Controls.Add(cmbGrade);
            pnlInputCard.Controls.Add(btnAdd);
            this.Controls.Add(pnlInputCard);

            dgvSubjects = new DataGridView();
            dgvSubjects.Location = new Point(25, 150);
            dgvSubjects.Size = new Size(820, 340);
            dgvSubjects.BackgroundColor = Color.White;
            dgvSubjects.BorderStyle = BorderStyle.None;
            dgvSubjects.RowHeadersVisible = false;
            dgvSubjects.AllowUserToAddRows = false;
            dgvSubjects.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSubjects.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvSubjects.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);

            dgvSubjects.EnableHeadersVisualStyles = false;
            dgvSubjects.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(30, 41, 59);
            dgvSubjects.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvSubjects.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            dgvSubjects.ColumnHeadersHeight = 38;

            dgvSubjects.Columns.Add("Code", "Course Code");
            dgvSubjects.Columns.Add("Name", "Course Name");
            dgvSubjects.Columns.Add("Credits", "Credits");
            dgvSubjects.Columns.Add("Grade", "Grade");
            dgvSubjects.Columns.Add("Points", "Grade Point");

            DataGridViewButtonColumn btnDeleteColumn = new DataGridViewButtonColumn();
            btnDeleteColumn.Name = "Delete";
            btnDeleteColumn.HeaderText = "Action";
            btnDeleteColumn.Text = "🗑️ Delete";
            btnDeleteColumn.UseColumnTextForButtonValue = true;
            dgvSubjects.Columns.Add(btnDeleteColumn);

            dgvSubjects.CellClick += DgvSubjects_CellClick;

            this.Controls.Add(dgvSubjects);

            btnCalculate = new Button();
            btnCalculate.Text = "🧮 Calculate GPA";
            btnCalculate.Location = new Point(25, 515);
            btnCalculate.Size = new Size(180, 42);
            btnCalculate.FlatStyle = FlatStyle.Flat;
            btnCalculate.FlatAppearance.BorderSize = 0;
            btnCalculate.BackColor = Color.FromArgb(34, 197, 94);
            btnCalculate.ForeColor = Color.White;
            btnCalculate.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnCalculate.Cursor = Cursors.Hand;
            btnCalculate.Click += BtnCalculate_Click;

            btnSave = new Button();
            btnSave.Text = "💾 Save & Close";
            btnSave.Location = new Point(695, 515);
            btnSave.Size = new Size(150, 42);
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.FlatAppearance.BorderSize = 0;
            btnSave.BackColor = Color.FromArgb(59, 130, 246);
            btnSave.ForeColor = Color.White;
            btnSave.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnSave.Cursor = Cursors.Hand;
            btnSave.Click += BtnSave_Click;

            AddHoverEffect(btnAdd, Color.FromArgb(37, 99, 235), Color.FromArgb(29, 78, 216));
            AddHoverEffect(btnCalculate, Color.FromArgb(34, 197, 94), Color.FromArgb(22, 163, 74));
            AddHoverEffect(btnSave, Color.FromArgb(59, 130, 246), Color.FromArgb(37, 99, 235));

            this.Controls.Add(btnCalculate);
            this.Controls.Add(btnSave);
        }

        private void AddHoverEffect(Button btn, Color normalColor, Color hoverColor)
        {
            btn.MouseEnter += (s, e) => btn.BackColor = hoverColor;
            btn.MouseLeave += (s, e) => btn.BackColor = normalColor;
        }

        private void LoadCoursesFromDatabase()
        {
            dgvSubjects.Rows.Clear();
            try
            {
                using (var connection = GPACalculator.Services.DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    string query = "SELECT CourseCode, CourseName, Credits, Grade, Points FROM Courses WHERE Semester = @semester;";
                    using (var cmd = new SqliteCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@semester", SemesterName);
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                dgvSubjects.Rows.Add(
                                    reader["CourseCode"].ToString(),
                                    reader["CourseName"].ToString(),
                                    reader["Credits"].ToString(),
                                    reader["Grade"].ToString(),
                                    Convert.ToDouble(reader["Points"]).ToString("0.00")
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveCoursesToDatabase()
        {
            try
            {
                using (var connection = GPACalculator.Services.DatabaseHelper.GetConnection())
                {
                    connection.Open();

                    string deleteQuery = "DELETE FROM Courses WHERE Semester = @semester;";
                    using (var delCmd = new SqliteCommand(deleteQuery, connection))
                    {
                        delCmd.Parameters.AddWithValue("@semester", SemesterName);
                        delCmd.ExecuteNonQuery();
                    }

                    foreach (DataGridViewRow row in dgvSubjects.Rows)
                    {
                        if (row.IsNewRow) continue;

                        string insertQuery = "INSERT INTO Courses (Semester, CourseCode, CourseName, Credits, Grade, Points) VALUES (@semester, @code, @name, @credits, @grade, @points);";
                        using (var insCmd = new SqliteCommand(insertQuery, connection))
                        {
                            insCmd.Parameters.AddWithValue("@semester", SemesterName);
                            insCmd.Parameters.AddWithValue("@code", row.Cells["Code"].Value?.ToString() ?? "");
                            insCmd.Parameters.AddWithValue("@name", row.Cells["Name"].Value?.ToString() ?? "");
                            insCmd.Parameters.AddWithValue("@credits", Convert.ToInt32(row.Cells["Credits"].Value));
                            insCmd.Parameters.AddWithValue("@grade", row.Cells["Grade"].Value?.ToString() ?? "");
                            insCmd.Parameters.AddWithValue("@points", Convert.ToDouble(row.Cells["Points"].Value));
                            insCmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving courses: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCourseCode.Text) || string.IsNullOrWhiteSpace(txtCourseName.Text) || string.IsNullOrWhiteSpace(txtCredits.Text))
            {
                MessageBox.Show("Please fill all subject fields!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtCredits.Text, out _))
            {
                MessageBox.Show("Credits must be a valid number!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string grade = cmbGrade.SelectedItem.ToString();
            double point = GetGradePoint(grade);

            dgvSubjects.Rows.Add(txtCourseCode.Text, txtCourseName.Text, txtCredits.Text, grade, point.ToString("0.00"));

            txtCourseCode.Clear();
            txtCourseName.Clear();
            txtCredits.Clear();
            cmbGrade.SelectedIndex = 0;
            txtCourseCode.Focus();
        }

        private void DgvSubjects_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvSubjects.Columns["Delete"].Index && e.RowIndex >= 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this course?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dgvSubjects.Rows.RemoveAt(e.RowIndex);
                }
            }
        }

        private double GetGradePoint(string grade)
        {
            switch (grade)
            {
                case "A+": case "A": return 4.0;
                case "A-": return 3.7;
                case "B+": return 3.3;
                case "B": return 3.0;
                case "B-": return 2.7;
                case "C+": return 2.3;
                case "C": return 2.0;
                case "C-": return 1.7;
                case "D": return 1.0;
                default: return 0.0;
            }
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            if (dgvSubjects.Rows.Count == 0)
            {
                MessageBox.Show("Please add at least one subject to calculate GPA.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            double totalPoints = 0;
            int totalCredits = 0;

            foreach (DataGridViewRow row in dgvSubjects.Rows)
            {
                int credits = Convert.ToInt32(row.Cells["Credits"].Value);
                double points = Convert.ToDouble(row.Cells["Points"].Value);

                totalPoints += (points * credits);
                totalCredits += credits;
            }

            double gpa = totalCredits > 0 ? totalPoints / totalCredits : 0.0;

            MessageBox.Show($"Semester GPA: {gpa.ToString("0.00")}", "GPA Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            SaveCoursesToDatabase();
            MessageBox.Show("Semester data saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}