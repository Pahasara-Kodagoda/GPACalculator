﻿namespace GPA_Calculator.Forms
{
    partial class SemesterForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            // අපි සියලුම Controls C# Code එකෙන්ම (SemesterForm.cs ඇතුළේ) 
            // නිර්මාණය කර ඇති නිසා මෙහි අමතර දේවල් අවශ්‍ය නොවේ.
            this.SuspendLayout();
            this.ResumeLayout(false);
        }
    }
}